// const connectToMongo = require('./db');
// const express = require('express')
// var cors = require('cors')

// connectToMongo();
// const app = express()
// const port = 5000


// app.use(cors())
// app.use(express.json())

// app.use('/api/auth',require('./routes/auth'))
// app.use('/api/notes',require('./routes/notes'))

// app.listen(port, () => {
//   console.log(`Example app listening on port ${port}`)
// })


// temprory run build 
const connectToMongo = require('./db');
const express = require('express');
const path = require('path');
var cors = require('cors');

connectToMongo();
const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/notes', require('./routes/notes'));

// Serve frontend static files
app.use(express.static(path.join(__dirname, "public")));

// Serve frontend for all other routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, "public", 'index.html'));
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
